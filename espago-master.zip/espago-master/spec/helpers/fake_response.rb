class FakeResponse < Struct.new(:status, :body)
end

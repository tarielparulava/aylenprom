Espago.app_id = espago_app_id
Espago.app_password = espago_app_password
Espago.public_key = espago_public_key
Espago.production = espago_production
Espago.api_version = espago_api_version
Espago.checksum_key = espago_checksum_key

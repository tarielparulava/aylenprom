module Espago
  class AuthenticationError < Error
  end
end

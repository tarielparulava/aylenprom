module Espago
  class ApiError < Error
  end
end

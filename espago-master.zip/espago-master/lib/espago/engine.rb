require 'rails'
module Espago
  class Engine < Rails::Engine
  end
end

module Espago
  class ApiConnection
    class Api
      def initialize(connection)
        @connection = connection
      end
    end
  end
end

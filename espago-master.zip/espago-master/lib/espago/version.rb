module Espago
  VERSION = "0.1.8"
end
